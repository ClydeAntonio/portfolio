export const portfolioContent = {
  header: {
    title: "SYSTEMS_ARCHITECT",
    version: "V5.4.0",
    status: "STABLE_BUILD",
  },
  hero: {
    role: "FULLSTACK DEVELOPER_V",
    tagline: "BUILDING RESILIENT DIGITAL ARCHITECTURES.",
    description: "Crafting robust digital ecosystems with precision and scalable backend architectures. I bridge the gap between systemic logic and cinematic user experiences.",
    primaryAction: "ESTABLISH_UPLINK",
    secondaryAction: "VIEW_SCHEMATICS",
  },
  about: {
    header: "SUB_HEADER: SYS",
    title: "BEYOND_THE_CODE",
    description: "I design bridges between conceptual architecture and durable implementations. My focus is on systemic logic and performance engineering, ensuring long-term maintainability. Every line of code is a structural beam in a larger digital landscape.",
    stats: [
      { label: "PRODUCT_AVAILABILITY", value: "99.9%" },
      { label: "MODEL_DRIVEN", value: "TRUE" },
    ]
  },
  projects: [
    {
      id: "LOG:001",
      title: "OMEGA_DASH",
      category: "TELEMETRY_SYSTEM",
      description: "Centralized ops console for system-wide performance telemetry.",
      tech: ["REACT", "GQL", "REDIS"],
      image: "https://images.unsplash.com/photo-1551288049-bbda48658a7d?auto=format&fit=crop&q=80&w=1000",
    },
    {
      id: "LOG:002",
      title: "PULSE_NETWORK",
      category: "DATA_FABRIC",
      description: "High-throughput data distribution and synchronization fabric.",
      tech: ["NODE.JS", "KAFKA", "GRPC"],
      image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1000",
    },
    {
      id: "LOG:003",
      title: "VOID_OS",
      category: "KERNEL_ARCH",
      description: "Decentralized operating system architecture optimized for WASM.",
      tech: ["RUST", "WASM", "EBPF"],
      image: "https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&q=80&w=1000",
    }
  ],
  links: [
    { label: "DIRECT_MAIL", value: "clydeantonio.work@gmail.com", type: "email" },
    { label: "VERSION_CONTROL", value: "github.com/architect", type: "url" },
    { label: "REMOTE_NODE", value: "linkedin.com/in/architect", type: "url" },
  ],
  contact: {
    title: "INITIALIZE_CONNECTION",
    description: "Propose your project. Engineering high-fidelity solutions that are robust and maintainable.",
    primaryAction: "DEPLOY_CONNECTION",
    secondaryAction: "DOWNLOAD_LOGS [CV]",
  },
  footer: {
    copyright: "© 2024 ARCHITECT_OS // STABLE_BUILD",
    metadata: [
      { label: "LATENCY", value: "14MS" },
      { label: "UPTIME", value: "99.9%" },
      { label: "ENCRYPTION", value: "AES-256" },
    ]
  }
};
